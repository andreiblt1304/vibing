export const synthwavePalette = {
  background: "#2d1836",
  sunTop: "#ffcf6b",
  sunMid: "#ff7b6b",
  sunBottom: "#d72660",
  palm: "#231942",
  accent1: "#ff6ec7",
  accent2: "#23d6d1",
  accent3: "#ffe156",
  player: "#23d6d1",
  enemy: "#ff6ec7",
  bullet: "#ffe156",
};
